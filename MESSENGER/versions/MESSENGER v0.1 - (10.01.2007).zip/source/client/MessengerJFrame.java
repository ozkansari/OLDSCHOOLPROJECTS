/*
 * MessengerJFrame.java
 *
 * Created on 07 Jan 2007 Sun, 01:12
 *
 */

package client;

import java.util.*;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.UIManager;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

import java.net.URL;
import java.io.IOException;
import java.awt.Dimension;
import java.awt.BorderLayout;

import util.DynamicTree;
import common.ClientInfo;

/**
 *
 * @author ozkansari
 */
public class MessengerJFrame extends JFrame  {
    
    private MessengerClient client;
    Vector onlineUsers;
    
    // User List tree
    private DynamicTree treePanel;
    private JTree usrtree;
    DefaultMutableTreeNode onlineUsers_Parent;

    /**
     * Creates a new instance of MessengerJFrame
     */
    public MessengerJFrame( String clientName, MessengerClient client ) {
        
        super( clientName );
        
        // set client connection     
        setClient( client );
        
        // set layout
        setLayout(new BorderLayout());
        
        // create and add tree
        createUserListTree();
        add(treePanel, BorderLayout.CENTER);
        
        // set up the window ////////////////////////////////////////
        setSize(new Dimension(300, 500));
        setLocation( 200, 200 );
        //setSize( boardPanel.getSize() );
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setDefaultLookAndFeelDecorated(true);
        
        setVisible(true);
        
    }

    private void createUserListTree() {

        treePanel = new DynamicTree( this );
        
        String p1Name = new String("Online Users");
        onlineUsers_Parent = treePanel.addObject(null, p1Name);
        
        initUserList();
        
    }
    
    private void initUserList() 
    {
        onlineUsers = getClient().getClientListVector();
        
        for( int i=0; i != onlineUsers.size() ; i++  ){
            
            ClientInfo current = (ClientInfo) onlineUsers.get(i) ;
            treePanel.addObject(onlineUsers_Parent, current);
        
        }
        
    }

    /**
     *  @description adds new chat dialog
     */
    public void addNewChatDialog( ChatDialogJFrame newDialog, int otherClientId  ) {
        getClient().getChatDialogVector().add( newDialog );
    }
    
    /**
     *  @description removes chat dialog
     */
    public void removeNewChatDialog( ChatDialogJFrame newDialog ) {
        getClient().getChatDialogVector().remove( newDialog );
    }
    
    /*  ***********************************************************************************************/
    /*	-- GETTER AND SETTER METHODS -----------------------------------------------------------------*/
    /*  ***********************************************************************************************/

    public MessengerClient getClient() {
        return client;
    }

    public void setClient(MessengerClient client) {
        this.client = client;
    }


    
}
