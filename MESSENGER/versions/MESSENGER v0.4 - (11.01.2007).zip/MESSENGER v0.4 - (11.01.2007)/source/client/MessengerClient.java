/*
 * MessengerClient.java
 *
 * Created on 04 Jan 2007 Thu, 01:19
 *
 */

package client;

// Java core packages
import java.io.*;
import java.net.*;
import java.util.*;

// My packages
import common.Message;
import common.ClientInfo;
import common.MyConstants;

/**
 *
 * @author ozkansari
 */
public class MessengerClient implements Runnable {
    
    private Thread thread;
    private String serverHost;
    private int connectionPort;

    // connection variables
    private Socket client;
    private ObjectOutputStream output;
    private ObjectInputStream input;
    
    // chat variables
    private static Vector theClientListVector ;
    private static Vector theChatDialogVector = new Vector();
    private Message message = null;
    
    // client info
    private ClientInfo thisClientInfo;
    
    // program variables
    private MessengerJFrame theMainFrameRef;
    
    /**
     * Creates a new instance of MessengerClient
     */
    public MessengerClient( String host, int port, String name ) {
        
      // set server to which this client connects
      setServerHost(host);
      connectionPort = port;
      setClientInfo( name, -1, host+":"+port, true);
              
      try {
          // Create a Socket to make connection
          connectToServer();
          
          // Get the input and output streams
          getStreams();
          
          // Init connection
          init();
          
          // start client
          thread = new Thread(this,"USER THREAD");
          thread.start();

          // process problems communicating with server
      } catch ( IOException ioException ) {
          ioException.printStackTrace();
      }
      
    }
    
    
    /**
     * connect to server and process messages from server
     */
    public void run() {
        // connect to server, get streams, process connection
        try {
            
//            // Create a Socket to make connection
//            connectToServer();
//            
//            // Get the input and output streams
//            getStreams();
//            
//            // Init connection
//            init();

            // process connection
            processConnection();
            
            // Close connection
            closeConnection();
        }
        
        // server closed connection
        catch ( EOFException eofException ) {
            System.out.println( "Server terminated connection" );
        }
        
        // process problems communicating with server
        catch ( IOException ioException ) {
            ioException.printStackTrace();
        }
    }

    /**
     *  connect to server
     */
    private void connectToServer() throws IOException 
    {
        if( MyConstants.IS_DEBUG ) {
            System.out.println( "Attempting connection\n" );
        }
        
        // create Socket to make connection to server
        client = new Socket( InetAddress.getByName( getServerHost()), connectionPort );
        
        // display connection information
        if( MyConstants.IS_DEBUG ) {
            System.out.println( "Connected to: " + client.getInetAddress().getHostName() );
        }

    }
    
    /**
     *  get streams to send and receive data
     */
    private void getStreams() throws IOException 
    {
        // set up output stream for objects
        output = new ObjectOutputStream( client.getOutputStream() );
        
        // flush output buffer to send header information
        output.flush();
        
        // set up input stream for objects
        input = new ObjectInputStream( client.getInputStream() );

        if( MyConstants.IS_DEBUG ) {
            System.out.println(  "Got I/O streams"  );
        }
    }
    
    /**
     *  init connection 
     */
    private void init() throws IOException 
    {    
        // send client info to server
        Message newClientMessage = new Message( -1, -1, thisClientInfo );
        sendMessage( newClientMessage );
        
        // get list of online clients
        try {
            message = ( Message ) input.readObject();
            
            if( message.getMessageType() == MyConstants.CLIENT_LIST ){
                theClientListVector = message.getClientListVector();
                thisClientInfo.setUserId( message.getDestinationId() );
            }
            
            if( MyConstants.IS_DEBUG ) {
                System.out.println( "got list of online clients" );
            }
           
        }
        catch ( ClassNotFoundException classNotFoundException ) {
            
            if( MyConstants.IS_DEBUG ) {
                System.out.println( "Unknown object type received" );
            }
        }
  
    }

    /**
     *  process connection with server
     */
    private void processConnection() throws IOException 
    {
        
        // process messages sent from server
        do {
            
            // read message and display it
            try {
                
                // read message
                message = ( Message ) input.readObject();
                System.out.println( "msg read is  " + message );
                
                // TODO: bu ifleri switch yap
                if( message.getMessageType() == MyConstants.NOTIFY_ONLINE_CLIENT ){
                    
                    // add new online user to the list and refresh user list tree
                    if( message.getNewClientInfo().getUserId() != thisClientInfo.getUserId() ) {
                        theClientListVector.add( message.getNewClientInfo() );
                        theMainFrameRef.refreshUserList();
                    }
                }
                
                if( message.getMessageType() == MyConstants.NOTIFY_OFFLINE_CLIENT ){
                    
                    for( int i=0; i < theClientListVector.size() ; i++ ) {
                        
                        // remove offline user from the list and refresh user list tree
                        ClientInfo current = (ClientInfo) theClientListVector.get( i );
                        if( current.getUserId() == message.getSourceId() ) {
                            theClientListVector.remove( current );
                        }
                    }
                    
                    
                    theMainFrameRef.refreshUserList();
                }
                
                if( message.getMessageType() == MyConstants.CLIENT_MESSAGE ){
                    
                    boolean dialogExists = false;
                    
                    // find the appropriate dialog and display message on it
                    for( int i=0; i < theChatDialogVector.size() ; i++ ) {
                        
                        ChatDialogJFrame current = (ChatDialogJFrame) theChatDialogVector.get( i );
                        
                        if( current.getOtherClientInfo().getUserId() == message.getSourceId() ) {
                            dialogExists = true;
                            current.displayNewMessage( message.getMsgString() );
                            System.out.println( ">>> " + message.getSourceId() + " - " + theChatDialogVector.get( i ) );
                            
                            current.focusIt();
                        }
                    }
                    
                    
                    // Kar��dan mesaj var ama current1 yok -> yarat o zaman
                    if( dialogExists == false ) {
                        
                        // !!! BUGGY: message.getSourceClientInfo().getUserId() is -1 ??? I don't know why
                        ClientInfo temp = message.getSourceClientInfo(); temp.setUserId( message.getSourceId() );
                        ChatDialogJFrame chatDialog = new ChatDialogJFrame( this , temp  );
                        theChatDialogVector.addElement( chatDialog );
                        chatDialog.displayNewMessage( message.getMsgString() );
                        
                        chatDialog.focusIt();
                        chatDialog.setVisible( true );
                        
                        System.out.println("dialog is created with destination id = " + message.getSourceClientInfo().getUserId()  );
                    }
                    
                }
                
                
                if( message.getMessageType() == MyConstants.FILE_SEND_MESSAGE ){
                    
                    boolean dialogExists = false;
                    ChatDialogJFrame current = null ;
                    
                    // find the appropriate dialog and display message on it
                    for( int i=0; i < theChatDialogVector.size() ; i++ ) {
                        
                        current = (ChatDialogJFrame) theChatDialogVector.get( i );
                        
                        if( current.getOtherClientInfo().getUserId() == message.getSourceId() ) {
                            dialogExists = true;
                            current.displayNewMessage( "File send request" );
                            System.out.println( ">>> " + message.getSourceId() + " - " + theChatDialogVector.get( i ) );

                            current.focusIt();
                        }
                    }
                    
                    
                    // Kar��dan mesaj var ama current1 yok -> yarat o zaman
                    if( dialogExists == false ) {
                        
                        // !!! BUGGY: message.getSourceClientInfo().getUserId() is -1 ??? I don't know why
                        ClientInfo temp = message.getSourceClientInfo(); temp.setUserId( message.getSourceId() );
                        current = new ChatDialogJFrame( this , temp  );
                        theChatDialogVector.addElement( current );
                        
                        current.displayNewMessage( "File send" );
                        
                        current.focusIt();
                        current.setVisible( true );
                        
                        System.out.println("dialog is created with destination id = " + message.getSourceClientInfo().getUserId()  );
                    }
                    
                    File selectedFile = current.askFileSave();
                    int fileLength = Integer.parseInt( message.getMsgString() );
                    readFile(fileLength, selectedFile);
                    
                    /////////////////////////////////////////////////////////////////////////////////////

                }
                
                
                if( MyConstants.IS_DEBUG ) {
                    System.out.println( message );
                }
                
                
            }
            
            // catch problems reading from server
            catch ( ClassNotFoundException classNotFoundException ) {
                
                if( MyConstants.IS_DEBUG ) {
                    System.out.println( "Unknown object type received" );
                }
            }
            
        } while ( true );
        
    }  // end method process connection


    /**
     *  close streams and socket
     */
    public void closeConnection() throws IOException {
        
        if( MyConstants.IS_DEBUG ) {
            System.out.println( "Closing connection" );
        }
 
        output.close();
        input.close();
        client.close();
    }
    
    
    /**
     *  NOT USING NOWWWWWWWWWWWWWW FOR LATER USEEEEEEEEEEEEEEEEEEEEEEEEEEE
     */
    public ChatDialogJFrame getChatDialogOf( int id, ClientInfo forNewCreation ){
        
        boolean dialogExists = false;
        
        // find the appropriate dialog and display message on it
        for( int i=0; i < theChatDialogVector.size() ; i++ ) {
            
            ChatDialogJFrame current = (ChatDialogJFrame) theChatDialogVector.get( i );
            
            if( current.getOtherClientInfo().getUserId() == id ) {
                dialogExists = true;
                return current;
            }
            
        }
        
        // Kar��dan mesaj var ama chatDialog yok -> yarat o zaman
        if( dialogExists == false ) {
            
            // !!! BUGGY: message.getSourceClientInfo().getUserId() is -1 ??? I don't know why
            ClientInfo temp = message.getSourceClientInfo(); temp.setUserId( message.getSourceId() );
            ChatDialogJFrame chatDialog = new ChatDialogJFrame( this , temp  );
            theChatDialogVector.addElement( chatDialog );
            
            System.out.println("dialog is created with destination id = " + message.getSourceClientInfo().getUserId()  );
            
            return chatDialog;
        }
        
        return null;
    }
    
    /**
     * send message to server
     */
    public void sendMessage( Message message ) 
    {
        // send object to server
        try {
            output.writeObject( message );
            //output.flush();
            
            if( MyConstants.IS_DEBUG ) {
                System.out.println( message );
            }

        }
        
        // process problems sending object
        catch ( IOException ioException ) {
            
            if( MyConstants.IS_DEBUG ) {
                System.out.println( "\nError writing object" );
            }

        }
    }
    
    /**
     *  Sends file to client whose info given as otherClientinfo parameter
     */
    public void sendFile( ClientInfo thisClientInfo, ClientInfo otherClientInfo,  File selectedFile) {
        
        if( selectedFile != null ) {
            
            Message newSendFileMessage = new Message( thisClientInfo, otherClientInfo, MyConstants.FILE_SEND_MESSAGE, ""+ selectedFile.length() );
            newSendFileMessage.setSourceId( thisClientInfo.getUserId() );
            newSendFileMessage.setDestinationId( otherClientInfo.getUserId() );

            try {
                java.io.FileInputStream fin = new java.io.FileInputStream(selectedFile);
                
                int length = fin.available();//Returns the number of bytes that can be read from this file input stream without blocking.
                
                // read file as byte
                byte[] data = new byte[length];
                fin.read(data,0,length);
                newSendFileMessage.fileByte = data;
                
                sendMessage( newSendFileMessage );
                
            }catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
  
        }
    }
    
    /**
     *  reads file from server to the selected file
     */
    private void readFile(final int fileLength, final File selectedFile) {
        
        FileOutputStream out;
        
        try{
            out = new FileOutputStream(selectedFile);
            
            byte[] data = message.fileByte;
            out.write(data,0,fileLength);
            
            out.close();
            
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    /*  ***********************************************************************************************/
    /*	-- GETTER AND SETTER METHODS -----------------------------------------------------------------*/
    /*  ***********************************************************************************************/
    
    public static Vector getClientListVector() {
        return theClientListVector;
    }

    public String getServerHost() {
        return serverHost;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }


    public void setClientInfo(String clientName, int clientId, String host, boolean isOnline ) {
        
        if( thisClientInfo == null )
            thisClientInfo = new ClientInfo( clientName, clientId , host, isOnline );
        else {
            thisClientInfo.setHostname( host );
            thisClientInfo.setUserName( clientName );
        }
    }
    
    public ClientInfo getClientInfo() {
        return thisClientInfo;
    }

    public static Vector getChatDialogVector() {
        return theChatDialogVector;
    }

    public static void setChatDialogVector(Vector chatDialogVector) {
        chatDialogVector = chatDialogVector;
    }

    public void setMainFrameRef(MessengerJFrame theMainFrameRef) {
        this.theMainFrameRef = theMainFrameRef;
    }
    
}
