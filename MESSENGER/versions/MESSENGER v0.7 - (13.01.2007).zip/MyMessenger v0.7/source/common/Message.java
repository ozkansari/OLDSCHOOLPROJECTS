/*
 * Message.java
 *
 * Created on 02 Jan 2007 Tue, 02:49
 *
 */

package common;

import java.io.File;
import java.util.Vector;

/**
 *
 * @author ozkansari
 */
public class Message implements java.io.Serializable {
    
    private static final long serialVersionUID = 1L;
    private int id = -1;
    
    // Message Content
    private String theMsgString = "";
    private Vector theClientListVector = null;
    private ClientInfo theNewClientInfo = null;
    
    private byte [] fileByte;
    
    // Message info
    private int theMessageType;
    private int theSourceId;
    private int theDestinationId;
    private ClientInfo theSourceClientInfo;
    private ClientInfo theDestinationClientInfo;
            
    /** 
     * Creates a new instance of Message as CLIENT_LIST message 
     *
     * @depreceated
     */
    public Message( int sourceId, int destinationId, Vector clientListVector ) {
        theSourceId = sourceId;
        theDestinationId = destinationId;
        theMessageType = MyConstants.CLIENT_LIST;
        theClientListVector = clientListVector;
    }
    
    /**
     * 
     * Creates a new instance of Message as NOTIFY_ONLINE_CLIENT message 
     * 
     * 
     * @depreceated 
     */
    public Message( int sourceId, int destinationId, ClientInfo newClientInfo ) {
        theSourceId = sourceId;
        theDestinationId = destinationId;
        theMessageType = MyConstants.NOTIFY_ONLINE_CLIENT;
        theNewClientInfo = newClientInfo;
    }
    
    /** 
     * Creates a new instance of Message 
     *
     * @depreceated
     */
    public Message( int sourceId, int destinationId, int messageType,  String msgString ) {
        theMessageType = messageType;
        theMsgString = msgString;
        theSourceId = sourceId;
        theDestinationId = destinationId;
    }
    
    /** Creates a new instance of Message */
    public Message( ClientInfo sourceClientInfo, ClientInfo destinationClientInfo, int messageType,  String msgString  ) {
        setSourceClientInfo(sourceClientInfo);
        setDestinationClientInfo(destinationClientInfo);
        theMessageType = messageType;
        theMsgString = msgString;
    }
    
    /** Creates a new instance of Message */
    public Message(  ) {

    }
    
    
    public String toString() {
        return theMessageType + " [" + getId() + "]" +": from " + getSourceId() +  " to " + getDestinationId() + " > " + theMsgString ;
    }
    
    /*  ***********************************************************************************************/
    /*	-- GETTER AND SETTER METHODS -----------------------------------------------------------------*/
    /*  ***********************************************************************************************/

    public String getMsgString() {
        return theMsgString;
    }

    public void setMsgString(String msgString) {
        this.theMsgString = msgString;
    }

    public int getMessageType() {
        return theMessageType;
    }

    public void setMessageType(int messageType) {
        this.theMessageType = messageType;
    }

    public int getSourceId() {
        return theSourceId;
    }

    public void setSourceId(int sourceId) {
        this.theSourceId = sourceId;
    }

    public int getDestinationId() {
        return theDestinationId;
    }

    public void setDestinationId(int destinationId) {
        this.theDestinationId = destinationId;
    }

    public java.util.Vector getClientListVector() {
        return theClientListVector;
    }

    public void setClientListVector(java.util.Vector clientListVector) {
        this.theClientListVector = clientListVector;
    }

    public ClientInfo getNewClientInfo() {
        return theNewClientInfo;
    }

    public void setNewClientInfo(ClientInfo newClientInfo) {
        this.theNewClientInfo = newClientInfo;
    }

    public ClientInfo getSourceClientInfo() {
        return theSourceClientInfo;
    }

    public void setSourceClientInfo(ClientInfo sourceClientInfo) {
        this.theSourceClientInfo = sourceClientInfo;
    }

    public ClientInfo getDestinationClientInfo() {
        return theDestinationClientInfo;
    }

    public void setDestinationClientInfo(ClientInfo destinationClientInfo) {
        this.theDestinationClientInfo = destinationClientInfo;
    }

    public byte[] getFileByte() {
        return fileByte;
    }

    public void setFileByte(byte[] fileByte) {
        this.fileByte = fileByte;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
}
