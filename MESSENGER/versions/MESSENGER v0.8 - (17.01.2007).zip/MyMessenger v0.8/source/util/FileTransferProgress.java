/*
 * FileTransferProgress.java
 *
 * Created on 14 Jan 2007 Sun, 01:22
 *
 */

package util;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 *
 * @author ozkansari
 */
public class FileTransferProgress {
    
    public final static int ONE_SECOND = 1000;
    private ProgressMonitor progressMonitor;
    private Timer timer;
    
    /**
     * Creates a new instance of FileTransferProgress
     */
    public FileTransferProgress() {

        
    }
    
    
    public void startProgressMonitor( Container parent, int taskLength) {
        
        progressMonitor = new ProgressMonitor( parent,
                "File is being transferred",
                "", 0, taskLength );
        progressMonitor.setProgress(0);
        progressMonitor.setMillisToDecideToPopup( 1 * ONE_SECOND);
    }
    
    public void setProgressValue( int newValue )
    {
        progressMonitor.setProgress( newValue);
    }
    
    public void stopProgressMonitor(){
        progressMonitor.close();
    }
    
    public void setProgressMessage( String message )
    {
        progressMonitor.setNote( message );
    }

    
}
