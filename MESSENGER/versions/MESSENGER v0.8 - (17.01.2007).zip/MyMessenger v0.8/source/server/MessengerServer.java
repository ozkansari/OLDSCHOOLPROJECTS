/*
 * MessengerServer.java
 *
 * Created on 02 Jan 2007 Tue, 02:26
 *
 */

package server;

// Java core packages
import java.net.*;
import java.io.*;
import java.util.*;

// Java extension packages
import javax.swing.*;

// My packages
import common.Message;
import common.MyConstants;

/**
 * MessengerServer
 *
 * This MessengerServer Class constructor
 *  - creates server sockets
 *  - creates a new thread, named ConnectionThread, to listen for new connections.
 *
 * Connected clients' information are stored in this class's clientListVector:Vector
 * Connected clients' handler threads are stored inside clientHandleVector:Vector
 *
 * This MessengerServer Class also has methods to
 *  - send given message (msg:Object) to sepecified client identified by its id (client id:int)
 *  - send given message (msg:Object) to all clients in clientHandleVector:Vector
 *
 * @author ozkansari
 */
public class MessengerServer  {
    
    // Display
    static ServerMonitorJFrame monitoringFrame ;
            
    // Connection variables
    private int serverPort ;
    protected static ServerSocket serverSocket;
    
    // handler that listens for new connections and that creates a new ClientHandler thread
    ConnectionHandle connectionHandler;
    
    protected static Vector clientHandleVector;     // stores client handle threads
    protected static Vector clientListVector;       // stores client information
    
    /**
     * Creates a new instance of MessengerServer
     *
     * @param port server port to listen for new connections
     */
    public MessengerServer( int port ) {
        
        serverPort = port;
        clientHandleVector = new Vector();
        clientListVector = new Vector();
        
        monitoringFrame = new ServerMonitorJFrame( );
        
        
        // create a ServerSocket :::
        try {
            serverSocket  = new ServerSocket(serverPort);
        } catch( IOException ioException ) {
            ioException.printStackTrace();
            System.exit( 1 );
        }
        
        if( MyConstants.IS_DEBUG ) {
            monitoringFrame.displayInformation("java MessengerServer " + serverPort );
            monitoringFrame.displayInformation( "MessengerServer started successfully... waiting for clients." );
        }
        
        // Create the thread that handles connections
        connectionHandler = new ConnectionHandle();
        connectionHandler.start();
    }
    
    
    /**
     *  @param Message msg
     */
    public static void sendMessageToAllClients( Message msg ) {
        
        for( int i=0; i != clientHandleVector.size() ; i++  ){
            
            try {
                
                ( (ClientHandle) clientHandleVector.get(i) ).getOutputStream().writeObject( msg );
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
        }
        
        monitoringFrame.displayMessage( "[BROADCAST MESSAGE] " + msg );
        
        if( msg.getMessageType() == MyConstants.NOTIFY_ONLINE_CLIENT || 
            msg.getMessageType() == MyConstants.NOTIFY_OFFLINE_CLIENT    
          ){
          monitoringFrame.displayInformation( "Client List is refreshed" );
          monitoringFrame.setClientList( clientListVector );
        }
        
    } //-end function Server.sendMessageToAllClients( Message )
    
    
    /**
     *  @param Message msg
     */
    public static void sendMessageTo( Object msg, int clientId ) {
        
        for( int i=0; i != clientHandleVector.size() ; i++  ){
            
            try {
                
                ClientHandle current = (ClientHandle) clientHandleVector.get(i) ;
                if ( current.getClientId() == clientId ) {
                    current.getOutputStream().writeObject( msg );
                    
                    monitoringFrame.displayMessage( msg.toString() );
                }
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
        }
        
        
        
    } //-end function Server.sendMessageToAllClients( Message )
    
    
    /*  ***********************************************************************************************/
    /*	-- GETTER AND SETTER METHODS -----------------------------------------------------------------*/
    /*  ***********************************************************************************************/
    
    public java.util.Vector getClientHandleVector() {
        return clientHandleVector;
    }
    
    public void setClientHandleVector(java.util.Vector clientHandleVector) {
        this.clientHandleVector = clientHandleVector;
    }
    
    public static Vector getClientListVector() {
        return clientListVector;
    }
    
    public static void setClientListVector(Vector aClientListVector) {
        clientListVector = aClientListVector;
    }
    
    /*  ***********************************************************************************************/
    /*	-- MAIN() FUNCTION ---------------------------------------------------------------------------*/
    /*  ***********************************************************************************************/
    
    /**
     *  main() function: executes Server side
     *
     *  @param String[] args
     */
    public static void main( String args[] ) {
        
        MessengerServer application = new MessengerServer( 5000 );
        
    } //-end function Server.main( String )
    
    
}
