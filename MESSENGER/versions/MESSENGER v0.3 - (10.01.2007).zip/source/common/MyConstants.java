/*
 * MyConstants.java
 *
 * Created on 23 Dec 2006 Saturday, 06:55
 */

package common;

/**
 *
 * @author ozkansari
 */
public class MyConstants {
    
    public static boolean IS_DEBUG = true;
    
    public static int CLIENT_LIST = 1000;
    public static int NOTIFY_ONLINE_CLIENT = 1001;
    public static int INIT_CLIENT = 1002;
    public static int NOTIFY_OFFLINE_CLIENT = 1003;
    public static int CLIENT_MESSAGE = 9001;
    public static int SERVER_MESSAGE = 9002;

}
