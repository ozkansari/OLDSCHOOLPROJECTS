/*
 * ChatDialogJFrame.java
 *
 * Created on 04 Ocak 2007 Per�embe, 14:07
 *
 */

package client;

// Java core packages
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;

// My packages
import common.Message;
import common.ClientInfo;
import common.MyConstants;

public class ChatDialogJFrame extends JFrame {
    
    private JTextField enterField;
    private JTextArea displayArea;
    
    private Socket client;
    private ObjectOutputStream output;
    private ObjectInputStream input;
   
    private MessengerClient clientRef = null;
    
    private String chatServer;
    private ClientInfo thisClientInfo;
    private ClientInfo otherClientInfo;

    
    // initialize chatServer and set up GUI
    public ChatDialogJFrame( MessengerClient client, ClientInfo otherClient ) 
    {
        super(  );
        
        clientRef = client;
        setThisClientInfo(client.getClientInfo());
        setOtherClientInfo(otherClient);
        
        Container container = getContentPane();
        
        // create enterField and register listener
        enterField = new JTextField();
        enterField.setEnabled( true );
        
        enterField.addActionListener(
                
            new ActionListener() {

                    // send message to server
                public void actionPerformed( ActionEvent event ) {

                    String msgString = thisClientInfo.getUserName() + " [" + thisClientInfo.getUserId() + "] " + "> "+ event.getActionCommand();
                    Message newClientMessage = new Message(  );
                    newClientMessage.setSourceId( getThisClientInfo().getUserId() );
                    newClientMessage.setDestinationId( getOtherClientInfo().getUserId() );
                    
                    newClientMessage.setSourceClientInfo( thisClientInfo );
                    newClientMessage.setDestinationClientInfo( otherClientInfo );
                    
                    newClientMessage.setMessageType( MyConstants.CLIENT_MESSAGE );
                    newClientMessage.setMsgString( msgString );
                    
                    clientRef.sendMessage( newClientMessage );
                    displayNewMessage( msgString );
                }
            
            }  // end anonymous inner class
        ); // end call to addActionListener
        
        // Window Listener to handle window closing
        this.addWindowListener(new WindowAdapter() {
            
            public void windowClosing(WindowEvent e) {
                if(JOptionPane.showConfirmDialog( getContentPane(),
                        "Are you sure you want to close chat ?",
                        "Quit Chat Dialog",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null) == JOptionPane.YES_OPTION) {
                    
                    clientRef.getChatDialogVector().removeElement( ChatDialogJFrame.this );
                    
                }
            }
        });
        
        container.add( enterField, BorderLayout.NORTH );
        
        // create displayArea
        displayArea = new JTextArea();
        container.add( new JScrollPane( displayArea ),
                BorderLayout.CENTER );
        
        setSize( 300, 150 );
        setTitle( "from " + thisClientInfo.getUserName() + " [" + thisClientInfo.getUserId() + "] " + 
                  "to " + otherClientInfo.getUserName() + " [" + otherClientInfo.getUserId() + "] " );
        setVisible( true );
    }
    
    
    public void displayNewMessage( String newMsg )
    {
        displayArea.append( "\n" + newMsg );
        displayArea.setCaretPosition(
                displayArea.getText().length() );
        enterField.setText( "" );
    }

    public void focusIt() {
        this.toFront();
    }

    
    public ClientInfo getThisClientInfo() {
        return thisClientInfo;
    }

    public void setThisClientInfo(ClientInfo thisClientInfo) {
        this.thisClientInfo = thisClientInfo;
    }

    public ClientInfo getOtherClientInfo() {
        return otherClientInfo;
    }

    public void setOtherClientInfo(ClientInfo otherClientInfo) {
        this.otherClientInfo = otherClientInfo;
    }
    

}
