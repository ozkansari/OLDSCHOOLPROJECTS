/*
 * MessengerServer.java
 *
 * Created on 02 Jan 2007 Tue, 02:26
 *
 */

package server;

// Java core packages
import java.net.*;
import java.io.*;
import java.util.*;

// My packages
import common.Message;
import common.MyConstants;

/**
 *
 * @author ozkansari
 */
public class MessengerServer {
    
    // Connection variables
    private int serverPort ;
    protected static ServerSocket serverSocket;
    ConnectionHandle connectionHandler;
            
    protected static Vector clientHandleVector;
    protected static Vector clientListVector;
    
    /** Creates a new instance of MessengerServer */
    public MessengerServer( int port ) {
        
        serverPort = port;
        clientHandleVector = new Vector();
        clientListVector = new Vector();
        
        // create a ServerSocket :::
        try {
            serverSocket  = new ServerSocket(serverPort);
        } catch( IOException ioException ) {
            ioException.printStackTrace();
            System.exit( 1 );
        }
        
        if( MyConstants.IS_DEBUG ) {
            System.out.println("java MessengerServer " + serverPort );
            System.out.println( "MessengerServer started successfully... waiting for clients." );
        }

        // Create the thread that handles connections
        connectionHandler = new ConnectionHandle();
        connectionHandler.start();
    }
    

    /**
     *  @param Message msg
     */
    public static void sendMessageToAllClients( Message msg ) {
        
        for( int i=0; i != clientHandleVector.size() ; i++  ){
            
            try {
                
                ( (ClientHandle) clientHandleVector.get(i) ).getOutputStream().writeObject( msg );
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
        }
        
    } //-end function Server.sendMessageToAllClients( Message )
    
    
    /**
     *  @param Message msg
     */
    public static void sendMessageTo( Object msg, int clientId ) {
        
        for( int i=0; i != clientHandleVector.size() ; i++  ){
            
            try {
                
                ClientHandle current = (ClientHandle) clientHandleVector.get(i) ;
                if ( current.getClientId() == clientId ) {
                    current.getOutputStream().writeObject( msg );
                    
                    System.out.println( ">>>" + msg + ">>>" + clientId );
                }
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
        }
        
    } //-end function Server.sendMessageToAllClients( Message )
    
    
    /*  ***********************************************************************************************/
    /*	-- GETTER AND SETTER METHODS -----------------------------------------------------------------*/
    /*  ***********************************************************************************************/

    public java.util.Vector getClientHandleVector() {
        return clientHandleVector;
    }

    public void setClientHandleVector(java.util.Vector clientHandleVector) {
        this.clientHandleVector = clientHandleVector;
    }
    
    public static Vector getClientListVector() {
        return clientListVector;
    }

    public static void setClientListVector(Vector aClientListVector) {
        clientListVector = aClientListVector;
    }
    
    /*  ***********************************************************************************************/
    /*	-- MAIN() FUNCTION ---------------------------------------------------------------------------*/
    /*  ***********************************************************************************************/
    
    /**
     *  main() function: executes Server side
     *
     *  @param String[] args
     */
    public static void main( String args[] ) {

        MessengerServer application = new MessengerServer( 5000 );
        
    } //-end function Server.main( String )


}
