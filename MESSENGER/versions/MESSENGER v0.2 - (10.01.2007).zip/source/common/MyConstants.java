/*
 * MyConstants.java
 *
 * Created on 23 Dec 2006 Saturday, 06:55
 */

package common;

/**
 *
 * @author ozkansari
 */
public class MyConstants {
    
    public static boolean IS_DEBUG = true;
    
    public static int CLIENT_LIST = 1111;
    public static int NOTIFY_NEW_CLIENT = 2222;
    public static int INIT_CLIENT = 3333;
    public static int CLIENT_MESSAGE = 4444;
    public static int SERVER_MESSAGE = 5555;

}
