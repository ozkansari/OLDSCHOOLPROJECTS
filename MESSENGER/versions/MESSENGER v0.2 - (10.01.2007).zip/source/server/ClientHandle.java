/*
 * ClientHandle.java
 *
 * Created on 02 Jan 2007 Tue, 02:31
 *
 */

package server;

// Java core packages
import java.net.*;
import java.io.*;
import java.util.*;

// My packages
import common.Message;
import common.MyConstants;

/**
 *
 * @author ozkansari ( ozkan_yellow@hotmail.com )
 */
public class ClientHandle extends Thread {
    
    // Client attributes
    private int clientId;
    private String clientName;
    
    // Connection Variables
    private Socket socket = null;
    
    // Streams
    private ObjectOutputStream outputStream = null;
    private ObjectInputStream inputStream = null;
    
    /*  ***********************************************************************************************/
    /*  -- CONSTRUCTOR -------------------------------------------------------------------------------*/
    /*  ***********************************************************************************************/
    
    /** Creates a newinstance of ClientHandle */
    public ClientHandle( Socket socket, int id ) 
    {
	super("Players");
    	
    	this.setClientId(id);       // mark clientId as its distinctive feature
        this.setSocket(socket);     // set connection socket
        
        // Get the input and output streams
        getStreams();
        
//        // get init message from client
//        Message initMsg = null;
//        try {
//            initMsg = (Message) getInputStream().readObject();
//        } catch (ClassNotFoundException ex) {
//            ex.printStackTrace();
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        }
//        
//        if( initMsg.getMessageType() == MyConstants.INIT_CLIENT ) {
//            clientName = initMsg.getMsgString();
//        }
        
    } // --end-ClientHandle-constructor--  
    
    /*  ***********************************************************************************************/
    /*	-- THREAD METHODS ----------------------------------------------------------------------------*/
    /*  ***********************************************************************************************/
    
    /**  The "ClientHandle.run()" method that controls thread's execution :
     *   It controls the information that is sent to the client and received from the client.
     */
    public void run() {
        
    	Message inputMsg, outputMsg;
        
        while ( true ) {
            
            try {

                // wait and read message
                inputMsg = ( Message ) getInputStream().readObject();

                if( MyConstants.IS_DEBUG ) {
                    System.out.println( "Message: \"" + inputMsg.getMsgString() + "\"" );
                }
                
                if( inputMsg.getMessageType() == MyConstants.INIT_CLIENT ) {
                    
                }
                
                if( inputMsg.getMessageType() == MyConstants.CLIENT_MESSAGE ) {
                    MessengerServer.sendMessageTo( inputMsg, inputMsg.getDestinationId() );
                }

            } 
            // catch problems
            catch (IOException e) {
                e.printStackTrace();
            } catch ( ClassNotFoundException e ) {
                System.out.println( "\nUnknown object type received" );
                e.printStackTrace();
            }   
            
        }
        

    	
    } //--end-Players.run()-method--  

    
    /*  ***********************************************************************************************/
    /*	-- HELPER METHODS ----------------------------------------------------------------------------*/
    /*  ***********************************************************************************************/    
    /**
     *  get streams to send and receive data
     */
    private void getStreams()
    {
        // obtain streams from Socket
        try {
            setOutputStream(new ObjectOutputStream(socket.getOutputStream()));
            setInputStream(new ObjectInputStream(socket.getInputStream() ));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /*  ***********************************************************************************************/
    /*	-- GETTER AND SETTER METHODS -----------------------------------------------------------------*/
    /*  ***********************************************************************************************/

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public ObjectOutputStream getOutputStream() {
        return outputStream;
    }

    public void setOutputStream(ObjectOutputStream outputStream) {
        this.outputStream = outputStream;
    }

    public ObjectInputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(ObjectInputStream inputStream) {
        this.inputStream = inputStream;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }
    
} // --end-ClientHandle-class--  
